%% Laboratorio 6 - Filtros Digitais
% Disciplina: Processamento Digital de Sinais - PD46CP
% Professor:  Lucas Bernardo Zilch
% Aluno:      Pedro Mariano

clear; close all; clc;

%% Atividade 1 - Leitura do sinal de audio (~30 s)
% Carrega um arquivo .mp3 (~30 s). O script aceita QUALQUER .mp3:
% se existir 'audio.mp3' na pasta ele e usado; caso contrario, o primeiro
% arquivo .mp3 encontrado na pasta atual e carregado automaticamente.
audioFile = 'audio.mp3';
if ~isfile(audioFile)
    listaMp3 = dir('*.mp3');
    if isempty(listaMp3)
        error(['Nenhum arquivo .mp3 encontrado na pasta atual. ' ...
               'Coloque um arquivo .mp3 (ex.: audio.mp3) junto deste script.']);
    end
    audioFile = listaMp3(1).name;
end

[xAudio, FA] = audioread(audioFile);

% Converte para mono (media dos canais) caso seja estereo/multicanal
if size(xAudio, 2) > 1
    xAudio = mean(xAudio, 2);
end
xAudio = xAudio(:);   % garante vetor coluna

% Recorta os primeiros 30 s (ou o sinal inteiro, se for menor)
duracaoSeg = 30;
maxSamples = min(length(xAudio), round(duracaoSeg * FA));
xAudio = xAudio(1:maxSamples);

fprintf('=== ATIVIDADE 1 ===\n');
fprintf('Arquivo: "%s" | Fs = %d Hz | duracao = %.1f s | %d amostras (mono).\n', ...
    audioFile, FA, length(xAudio)/FA, length(xAudio));

%% Atividade 2 - Passa-baixas (ordem 10): janela retangular vs Hamming
fc  = 500;                 % frequencia de corte do passa-baixas (Hz)
wc  = 2*pi*fc/FA;          % frequencia angular digital de corte
Ordem0 = 10;               % ordem inicial
NFFT2  = 8192;             % zero-padding p/ densificar o espectro

% a) Janela retangular forcada
b_rect = fir1(Ordem0, wc/pi, rectwin(Ordem0+1));
% b) Janela de Hamming (default do fir1)
b_hamm = fir1(Ordem0, wc/pi);

[f2, Hdb_rect] = respFreqDB(b_rect, NFFT2, FA);
[~,  Hdb_hamm] = respFreqDB(b_hamm, NFFT2, FA);
metade2 = 1:floor(NFFT2/2);

figure('Name','Atividade 2 - Passa-baixas ordem 10 (Retangular x Hamming)');
plot(f2(metade2), Hdb_rect(metade2), 'r', 'LineWidth', 1.2); hold on;
plot(f2(metade2), Hdb_hamm(metade2), 'b', 'LineWidth', 1.2);
grid on;
xlabel('Frequencia (Hz)'); ylabel('Magnitude (dB)');
title(sprintf('Passa-baixas fc = %d Hz, ordem %d', fc, Ordem0));
legend('Janela retangular', 'Janela de Hamming', 'Location', 'northeast');
xlim([0 5000]); ylim([-100 5]);

fprintf('\n=== ATIVIDADE 2 ===\n');
fprintf(['Com ordem %d, a janela retangular tem transicao mais abrupta, porem lobulos\n' ...
         'laterais altos (~ -21 dB). A janela de Hamming atenua muito mais os lobulos\n' ...
         '(~ -53 dB), ao custo de uma transicao mais suave (mais larga).\n'], Ordem0);

%% Atividade 3 - Aumenta a ordem (Hamming) ate >= 80 dB acima de 1000 Hz
fstop  = 1000;             % a partir daqui exige-se atenuacao >= 80 dB
attMin = 80;               % atenuacao minima exigida (dB)
NFFT3  = 65536;            % resolucao fina p/ medir o pior caso do stopband
ordemMax = 8000;           % limite de seguranca da busca

fprintf('\n=== ATIVIDADE 3 ===\n');
fprintf('Procurando a ordem (Hamming) p/ >= %d dB de atenuacao em f > %d Hz...\n', ...
    attMin, fstop);

Ordem   = Ordem0;
piorGanho = 0;
while Ordem <= ordemMax
    bL = fir1(Ordem, wc/pi);                  % passa-baixas, Hamming
    [f3, Hdb] = respFreqDB(bL, NFFT3, FA);
    banda = (f3 > fstop) & (f3 <= FA/2);
    piorGanho = max(Hdb(banda));              % maior ganho (pior caso) no stopband
    if piorGanho <= -attMin
        break;
    end
    Ordem = Ordem + 2;                        % ordem par (necessaria p/ o passa-altas)
end

if piorGanho > -attMin
    warning('Nao atingiu %d dB ate a ordem %d (pior ganho = %.1f dB).', ...
        attMin, ordemMax, piorGanho);
end
fprintf('Ordem necessaria: %d  ->  pior ganho em f > %d Hz = %.1f dB.\n', ...
    Ordem, fstop, piorGanho);

% Espectro do passa-baixas final
figure('Name','Atividade 3 - Passa-baixas Hamming (>= 80 dB acima de 1000 Hz)');
plot(f3(1:floor(NFFT3/2)), Hdb(1:floor(NFFT3/2)), 'b', 'LineWidth', 1.0); hold on;
yline(-attMin, '--k', sprintf('-%d dB', attMin));
xline(fstop,  '--r', sprintf('%d Hz', fstop));
grid on;
xlabel('Frequencia (Hz)'); ylabel('Magnitude (dB)');
title(sprintf('Passa-baixas Hamming - ordem %d', Ordem));
xlim([0 5000]); ylim([-140 5]);

fprintf(['Observacao: a janela de Hamming satura a atenuacao perto da transicao\n' ...
         '(~ -53 dB) e so melhora muito lentamente longe do corte. Por isso a ordem\n' ...
         'necessaria p/ 80 dB e MUITO alta (filtro longo) e o resultado e marginal:\n' ...
         'ordens vizinhas podem voltar a ficar acima de -80 dB. Para 80 dB de forma\n' ...
         'robusta o ideal seria uma janela com mais atenuacao (Blackman ~ordem 460 ou\n' ...
         'Kaiser ~ordem 230). Mantemos Hamming por ser o pedido no roteiro.\n']);

%% Atividade 4 - Aplica o passa-baixas (Ativ. 3) no audio -> GRAVES
graves = conv(xAudio, bL);
fprintf('\n=== ATIVIDADE 4 ===\n');
fprintf('Passa-baixas (fc = %d Hz, ordem %d) aplicado via conv() -> GRAVES.\n', fc, Ordem);

%% Atividade 5 - Passa-altas em 4000 Hz (mesma ordem) -> AGUDOS
fc2 = 4000;                 % frequencia de corte do passa-altas (Hz)
wc2 = 2*pi*fc2/FA;
bH  = fir1(Ordem, wc2/pi, 'High');   % passa-altas, mesma ordem da Ativ. 3
agudos = conv(xAudio, bH);
fprintf('\n=== ATIVIDADE 5 ===\n');
fprintf('Passa-altas (fc = %d Hz, ordem %d) aplicado via conv() -> AGUDOS.\n', fc2, Ordem);

%% Atividade 6 - Passa-faixas 500-4000 Hz (mesma ordem) -> MEDIOS
bB = fir1(Ordem, [wc wc2]/pi);       % Wn com 2 elementos -> passa-faixas
medios = conv(xAudio, bB);
fprintf('\n=== ATIVIDADE 6 ===\n');
fprintf('Passa-faixas (%d-%d Hz, ordem %d) aplicado via conv() -> MEDIOS.\n', fc, fc2, Ordem);

% Espectros dos tres filtros sobrepostos (para comparar as bandas)
[ff, HdbL] = respFreqDB(bL, NFFT2, FA);
[~,  HdbH] = respFreqDB(bH, NFFT2, FA);
[~,  HdbB] = respFreqDB(bB, NFFT2, FA);
metadeF = 1:floor(NFFT2/2);
figure('Name','Atividades 4-6 - Bandas: graves / medios / agudos');
plot(ff(metadeF), HdbL(metadeF), 'b', 'LineWidth', 1.0); hold on;
plot(ff(metadeF), HdbB(metadeF), 'g', 'LineWidth', 1.0);
plot(ff(metadeF), HdbH(metadeF), 'r', 'LineWidth', 1.0);
grid on;
xlabel('Frequencia (Hz)'); ylabel('Magnitude (dB)');
title('Respostas: passa-baixas, passa-faixas e passa-altas');
legend('Graves (PB)', 'Medios (PF)', 'Agudos (PA)', 'Location', 'southwest');
xlim([0 8000]); ylim([-140 5]);

%% Atividade 7 - Reproducao dos audios filtrados
% Normaliza cada sinal apenas para a reproducao, evitando clipping no sound().
fprintf('\n=== ATIVIDADE 7 ===\n');
reproduzir('Original',            xAudio, FA);
reproduzir('Graves (passa-baixas)', graves, FA);
reproduzir('Agudos (passa-altas)',  agudos, FA);
reproduzir('Medios (passa-faixas)', medios, FA);

fprintf(['\nComparacao: os GRAVES soam abafados (so o corpo/bumbo/baixo passam),\n' ...
         'os AGUDOS soam finos/chiados (pratos, sibilancia) e os MEDIOS concentram\n' ...
         'voz e instrumentos centrais, sem o grave nem o brilho dos agudos.\n']);

%% ---------- Funcoes locais ----------
function [f, Hdb] = respFreqDB(b, NFFT, FA)
%RESPFREQDB Resposta em frequencia (dB) de um filtro FIR com zero-padding.
    if NFFT < numel(b)
        NFFT = 2^nextpow2(numel(b));
    end
    H   = fft([b(:).', zeros(1, NFFT - numel(b))]);
    f   = (0:NFFT-1) * FA / NFFT;
    Hdb = 20*log10(abs(H) + eps);
end

function reproduzir(nome, y, FA)
%REPRODUZIR Toca um sinal normalizado e espera o fim da reproducao.
    fprintf('Reproduzindo: %s ...\n', nome);
    y = y / (max(abs(y)) + eps);     % normaliza p/ evitar clipping
    sound(y, FA);
    pause(length(y)/FA + 0.5);
end
