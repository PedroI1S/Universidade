%% Laboratorio 4 - Comparacao DTFT e FFT
% Disciplina: Processamento Digital de Sinais - PD46CP
% Professor:  Lucas Bernardo Zilch
% Aluno:      Pedro Mariano

clear; close all; clc;

%% Atividade 1 - Sinal x[n] e sua DTFT
% Sinal: x[n] = (cos(0.2*pi*n) + 0.5*sin(0.4*pi*n)) * (u[n] - u[n-32])
% Indexacao conforme o roteiro (i = 1..NA), implementando a janela u[n]-u[n-32].
NA = 32;
n = 0:NA-1;
x = zeros(1, NA);
for i = 1:NA
    if i < 33
        x(i) = cos(0.2*pi*i) + 0.5*sin(0.4*pi*i);
    else
        x(i) = 0;
    end
end

omega = -pi:0.001:pi;
X = zeros(size(omega));
for i = 1:length(omega)
    X(i) = sum(x .* exp(-1j*omega(i)*n));
end

figure('Name','Atividade 1');
subplot(2,1,1);
stem(n, x, 'filled');
grid on;
xlabel('n');
ylabel('x[n]');
title('Sinal x[n]');

subplot(2,1,2);
plot(omega, abs(X), 'LineWidth', 1.2);
grid on;
xlabel('omega (rad/amostra)');
ylabel('|X(e^{j\omega})|');
title('Modulo da DTFT');

%% Atividade 2 - Comparacao DTFT x FFT (N = 32)
X_fft = fft(x);
omega_fft = 2*pi*(0:length(x)-1)/length(x);

figure('Name','Atividade 2');
plot(omega, abs(X), 'LineWidth', 1.2); hold on;
stem(omega_fft, abs(X_fft), 'o');
grid on;
xlabel('omega (rad/amostra)');
ylabel('Magnitude');
title('DTFT (linha) e FFT (amostras)');
legend('DTFT', 'FFT', 'Location', 'best');

%% Atividade 2c - Mesmo sinal com N = 128 (zero-padding)
NA2 = 128;
n2 = 0:NA2-1;
x2 = zeros(1, NA2);
for i = 1:NA2
    if i < 33
        x2(i) = cos(0.2*pi*i) + 0.5*sin(0.4*pi*i);
    else
        x2(i) = 0;
    end
end

omega2 = -pi:0.001:pi;
X2 = zeros(size(omega2));
for i = 1:length(omega2)
    X2(i) = sum(x2 .* exp(-1j*omega2(i)*n2));
end

X2_fft = fft(x2);
omega2_fft = 2*pi*(0:length(x2)-1)/length(x2);

figure('Name','Atividade 2c');
plot(omega2, abs(X2), 'LineWidth', 1.2); hold on;
stem(omega2_fft, abs(X2_fft), 'o');
grid on;
xlabel('omega (rad/amostra)');
ylabel('Magnitude');
title('DTFT (linha) e FFT (N=128)');
legend('DTFT', 'FFT N=128', 'Location', 'best');

fprintf('\n=== ATIVIDADE 2c: Analise ===\n');
fprintf(['A DTFT NAO muda: o sinal continua o mesmo (zeros a partir de n = 32) e a\n' ...
         'DTFT e uma funcao continua de omega que independe do numero de amostras N.\n']);
fprintf(['A FFT MUDA: com N = 128 (zero-padding) ela passa a amostrar a MESMA DTFT em\n' ...
         '128 pontos, em vez de 32. As raias ficam mais densas/proximas e revelam melhor\n' ...
         'o formato da DTFT. Isso aumenta a resolucao de VISUALIZACAO (interpolacao no\n' ...
         'dominio da frequencia), mas nao acrescenta informacao nova ao espectro.\n']);

%% Atividade 3 - Remocao de ruido de 1 kHz via FFT/IFFT
% Carrega um arquivo de audio mp3 (~10 s). O script aceita QUALQUER .mp3:
% se existir 'audio.mp3' na pasta ele e usado; caso contrario, o primeiro
% arquivo .mp3 encontrado na pasta atual e carregado automaticamente.
audioFile = 'audio.mp3';
if ~isfile(audioFile)
    listaMp3 = dir('*.mp3');
    if isempty(listaMp3)
        error(['Nenhum arquivo .mp3 encontrado na pasta atual. ' ...
               'Coloque um arquivo .mp3 (ex.: audio.mp3) junto deste script.']);
    end
    audioFile = listaMp3(1).name;
end
fprintf('\n=== ATIVIDADE 3 ===\n');
fprintf('Arquivo de audio utilizado: "%s".\n', audioFile);

[xAudio, FA] = audioread(audioFile);

% Converte para mono (media dos canais) caso seja estereo/multicanal
if size(xAudio, 2) > 1
    xAudio = mean(xAudio, 2);
end
xAudio = xAudio(:);   % garante vetor coluna

% Usa aproximadamente os primeiros 10 s (ou o sinal inteiro, se for menor)
duracaoSeg = 10;
maxSamples = min(length(xAudio), round(duracaoSeg * FA));
xAudio = xAudio(1:maxSamples);
fprintf('Fs = %d Hz | duracao usada = %.2f s | %d amostras (mono).\n', ...
    FA, length(xAudio)/FA, length(xAudio));

% Gera ruido senoidal em 1 kHz com o mesmo numero de amostras do audio
f0 = 1000;
t = (0:length(xAudio)-1).' / FA;     % vetor coluna de tempo
ruido = 0.3 * sin(2*pi*f0*t);

% Soma audio + ruido
xRuido = xAudio + ruido;

% FFT do sinal com ruido
N = length(xRuido);
Xruido = fft(xRuido);
f = (0:N-1).' * FA / N;

figure('Name','Atividade 3 - FFT com ruido');
plot(f, abs(Xruido), 'LineWidth', 1.0);
grid on;
xlabel('Frequencia (Hz)');
ylabel('Magnitude');
title('FFT do sinal com ruido (pico em 1 kHz)');
xlim([0 min(5000, FA/2)]);

% Zera a componente de 1 kHz (raia positiva e sua espelhada negativa)
k = round(f0 / FA * N);          % indice (base 0) da raia mais proxima de 1 kHz
idx_pos = k + 1;                 % MATLAB usa indexacao base 1
idx_neg = N - k + 1;             % raia espelhada (frequencia negativa)
Xruido(idx_pos) = 0;
Xruido(idx_neg) = 0;

% Reconstrucao no dominio do tempo
xLimpo = real(ifft(Xruido));

% Reproducao para comparacao auditiva
fprintf('Reproduzindo audio original...\n');
sound(xAudio, FA);
pause(length(xAudio)/FA + 0.5);

fprintf('Reproduzindo audio com ruido de 1 kHz...\n');
sound(xRuido, FA);
pause(length(xRuido)/FA + 0.5);

fprintf('Reproduzindo audio apos remover a componente de 1 kHz...\n');
sound(xLimpo, FA);
pause(length(xLimpo)/FA + 0.5);

% Analise (Atividade 3g)
fprintf('\n=== ATIVIDADE 3g: Analise ===\n');
fprintf(['Ao somar a senoide de %d Hz, surge no espectro um pico bem definido em\n' ...
         '%d Hz (e seu espelho em Fs - %d Hz = %d Hz).\n'], f0, f0, f0, FA - f0);
fprintf(['Zerando essas raias e aplicando a IFFT, o tom de %d Hz e praticamente\n' ...
         'eliminado e o audio volta a soar muito proximo do original.\n'], f0);
fprintf(['Observacao: a remocao e perfeita quando %d Hz cai exatamente sobre uma raia\n' ...
         'da FFT (f0*N/Fs inteiro); caso contrario ha leve vazamento espectral para as\n' ...
         'raias vizinhas e um pequeno residuo audivel.\n'], f0);
