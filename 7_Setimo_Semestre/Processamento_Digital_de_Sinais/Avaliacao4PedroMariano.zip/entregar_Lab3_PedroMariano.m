%% Laboratorio 3 - Representacoes de Fourier por FFT
% Disciplina: Processamento Digital de Sinais - PD46CP
% Professor:  Lucas Bernardo Zilch
% Aluno:      Pedro Mariano

clear; close all; clc;

%% Definicoes Gerais

FA = 500;      % Frequência de Amostragem (Hz) para Atividade 1
NA = 51;       % Numero de amostras para Atividade 1

n = 0:1:NA-1;   % Indices das amostras
t = n./FA;      % Vetor de tempo (segundos)
f = (0:NA-1) * FA / NA;  % Vetor de frequencias em Hz (normalmente 0 ate FA)

FSenoideArray = [20, 100, 200, 250, 300, 400];  % Frequencias a testar (Hz)

%% Atividade 1 - Amostragem de senoides e aliasing
for idx = 1:length(FSenoideArray)
    FSenoide = FSenoideArray(idx);
    
    % Gerar senoide continua (para visualizacao)
    t1 = 0:0.0001:NA/FA;
    Sinal1 = sin(2*pi*FSenoide*t1);
    
    % Senoide amostrada
    Sinal1Amostrado = sin(2*pi*FSenoide*t);
    
    % FFT e espectro em magnitude
    FFT_Sinal = fft(Sinal1Amostrado);
    Espectro = abs(FFT_Sinal);
    
    % Numero de amostras por ciclo
    amostras_por_ciclo = FA / FSenoide;
    
    % Criar figura com 2 subplots
    figure('Name', sprintf('Atividade 1 - Senoide de %d Hz', FSenoide));
    
    % Subplot 1: Senoide continua vs amostras
    subplot(2,1,1);
    plot(t1, Sinal1, 'b-', 'LineWidth', 1.5); hold on;
    stem(t, Sinal1Amostrado, 'ro', 'LineWidth', 1.5);
    title(sprintf('Senoide Amostrada: f = %d Hz, Fs = %d Hz (%.2f amostras/ciclo)', ...
        FSenoide, FA, amostras_por_ciclo));
    xlabel('Tempo [s]');
    ylabel('Amplitude');
    xlim([0 NA/FA]);
    ylim([-1.2 1.2]);
    grid on;
    legend('Senoide continua', 'Amostras');
    
    % Subplot 2: Espectro de frequencias
    subplot(2,1,2);
    stem(f, Espectro, 'b', 'LineWidth', 1.5);
    title('Espectro em Frequencia (Magnitude da FFT)');
    xlabel('Frequencia [Hz]');
    ylabel('Modulo');
    xlim([0 max(f)]);
    grid on;
    
    % Informacoes importantes
    fprintf('\n=== Frequencia de Senoide: %d Hz ===\n', FSenoide);
    fprintf('Frequencia de Amostragem (Fs): %d Hz\n', FA);
    fprintf('Frequencia de Nyquist (Fs/2): %.1f Hz\n', FA/2);
    fprintf('Amostras por ciclo: %.2f\n', amostras_por_ciclo);
    
    % Detectar picos no espectro (sem Signal Processing Toolbox)
    espectro_half = Espectro(1:floor(end/2));
    if max(espectro_half) < 1e-6
        % Sinal amostrado praticamente nulo (ex.: f = Nyquist): so resta ruido numerico
        fprintf('Picos detectados no espectro em: nenhum (sinal amostrado praticamente nulo).\n');
    else
        limiar = max(espectro_half) * 0.1;
        picos_idx = [];
        for i = 2:length(espectro_half)-1
            if espectro_half(i) > espectro_half(i-1) && espectro_half(i) > espectro_half(i+1) && espectro_half(i) > limiar
                picos_idx = [picos_idx, i];
            end
        end
        freq_picos = f(picos_idx);
        fprintf('Picos detectados no espectro em: ');
        for p = 1:length(freq_picos)
            fprintf('%.1f Hz ', freq_picos(p));
        end
        fprintf('\n');
    end
end

fprintf('\n=== OBSERVACOES SOBRE ALIASING (Atividade 1e) ===\n');
fprintf('- Ate 200 Hz (< Nyquist = %.0f Hz): a representacao em frequencia e coerente.\n', FA/2);
fprintf('- Em 250 Hz (= Nyquist = Fs/2): caso limite. Como sin(2*pi*250*n/500) = sin(pi*n) = 0,\n');
fprintf('  a senoide amostrada resulta praticamente NULA em todas as amostras (amostragem\n');
fprintf('  nos cruzamentos por zero) e o espectro fica sem pico definido.\n');
fprintf('- Em 300 Hz e 400 Hz (> Nyquist): ocorre aliasing. O pico aparece rebatido em\n');
fprintf('  Fs - f = %.0f Hz e %.0f Hz, respectivamente (frequencia errada).\n', FA-300, FA-400);
fprintf('- Frequencia maxima observavel com a FFT: Nyquist = Fs/2 = %.0f Hz.\n', FA/2);
fprintf('- Aliasing: sinais com frequencia > Nyquist sao rebatidos para frequencias menores.\n');


%% Atividade 2 - Espectro em frequencia de uma onda quadrada
% Parametros da Atividade 2
Fa2 = 1000;         % Frequencia de amostragem (Hz)
f0_quad = 20;       % Frequencia fundamental da onda quadrada (Hz)
Na2_full = 1000;    % Numero de amostras para primeiro teste

% Atividade 2a e 2b: Gerar onda quadrada com 1000 amostras
t2 = (0:Na2_full-1) / Fa2;  % Vetor de tempo
% Gerar onda quadrada sem Signal Processing Toolbox
onda_quadrada_full = sign(sin(2*pi*f0_quad*t2));  % Onda quadrada entre -1 e 1

% Calculo da FFT
FFT_onda_quad_full = fft(onda_quadrada_full);
Espectro_quad_full = abs(FFT_onda_quad_full);

% Vetor de frequencias
f_quad_full = (0:Na2_full-1) * Fa2 / Na2_full;

% Atividade 2c: Mostrar em mesma figura onda quadrada e espectro
figure('Name', 'Atividade 2 - Onda Quadrada (1000 amostras)');

% Subplot 1: Forma de onda
subplot(2,1,1);
plot(t2(1:200), onda_quadrada_full(1:200), 'b-', 'LineWidth', 1.5);
title(sprintf('Onda Quadrada: f = %d Hz, Fs = %d Hz, N = %d amostras', ...
    f0_quad, Fa2, Na2_full));
xlabel('Tempo [s]');
ylabel('Amplitude');
grid on;
xlim([0 0.2]);

% Subplot 2: Espectro de frequencias (apenas ate Nyquist)
subplot(2,1,2);
freq_plot = f_quad_full(1:floor(Na2_full/2));
espectro_plot = Espectro_quad_full(1:floor(Na2_full/2));
stem(freq_plot, espectro_plot, 'b', 'LineWidth', 1.5);
title('Espectro em Frequencia (Magnitude da FFT)');
xlabel('Frequencia [Hz]');
ylabel('Modulo');
xlim([0 200]);
grid on;

% Atividade 2d: Analise dos componentes em frequencia
fprintf('\n=== ATIVIDADE 2d: Componentes em Frequencia ===\n');
fprintf('Uma onda quadrada "perfeita" tem componentes apenas em multiplos impares\n');
fprintf('da frequencia fundamental.\n');
fprintf('Fundamental: %d Hz\n', f0_quad);
fprintf('Harmonicos esperados: ');
for k = 1:2:11
    fprintf('%d Hz ', f0_quad * k);
end
fprintf('\n\n');

% Detectar picos principais no espectro (sem Signal Processing Toolbox)
threshold = max(Espectro_quad_full) * 0.05;
picos_idx_2d = [];
for i = 2:length(espectro_plot)-1
    if espectro_plot(i) > espectro_plot(i-1) && espectro_plot(i) > espectro_plot(i+1) && espectro_plot(i) > threshold
        picos_idx_2d = [picos_idx_2d, i];
    end
end
freq_picos_2d = freq_plot(picos_idx_2d);
picos_mag = espectro_plot(picos_idx_2d);

fprintf('Picos detectados no espectro (com N=%d):\n', Na2_full);
fprintf('Frequencia [Hz] | Amplitude\n');
fprintf('----------------+-----------\n');
for i = 1:min(10, length(freq_picos_2d))
    fprintf('%.1f            | %.2f\n', freq_picos_2d(i), picos_mag(i));
end

% Atividade 2e: Teste com apenas 51 amostras (aliasing)
fprintf('\n\n=== ATIVIDADE 2e: Efeito de Aliasing (N = 51 amostras) ===\n');

Na2_short = 51;
t2_short = (0:Na2_short-1) / Fa2;
% Gerar onda quadrada sem Signal Processing Toolbox
onda_quadrada_short = sign(sin(2*pi*f0_quad*t2_short));

FFT_onda_quad_short = fft(onda_quadrada_short);
Espectro_quad_short = abs(FFT_onda_quad_short);
f_quad_short = (0:Na2_short-1) * Fa2 / Na2_short;

figure('Name', 'Atividade 2e - Onda Quadrada (51 amostras - Aliasing)');

% Subplot 1: Forma de onda
subplot(2,1,1);
plot(t2_short, onda_quadrada_short, 'r-', 'LineWidth', 1.5);
stem(t2_short, onda_quadrada_short, 'ro', 'LineWidth', 1);
title(sprintf('Onda Quadrada com Aliasing: f = %d Hz, Fs = %d Hz, N = %d amostras', ...
    f0_quad, Fa2, Na2_short));
xlabel('Tempo [s]');
ylabel('Amplitude');
grid on;

% Subplot 2: Espectro
subplot(2,1,2);
freq_plot_short = f_quad_short(1:floor(Na2_short/2));
espectro_plot_short = Espectro_quad_short(1:floor(Na2_short/2));
stem(freq_plot_short, espectro_plot_short, 'r', 'LineWidth', 1.5);
title('Espectro em Frequencia (com Aliasing)');
xlabel('Frequencia [Hz]');
ylabel('Modulo');
xlim([0 300]);
grid on;

% Detectar componentes (sem Signal Processing Toolbox)
threshold_short = max(Espectro_quad_short) * 0.05;
picos_idx_short = [];
for i = 2:length(espectro_plot_short)-1
    if espectro_plot_short(i) > espectro_plot_short(i-1) && espectro_plot_short(i) > espectro_plot_short(i+1) && espectro_plot_short(i) > threshold_short
        picos_idx_short = [picos_idx_short, i];
    end
end
freq_picos_short = freq_plot_short(picos_idx_short);
picos_mag_short = espectro_plot_short(picos_idx_short);

fprintf('Picos detectados com N=%d (mais componentes due aliasing):\n', Na2_short);
fprintf('Frequencia [Hz] | Amplitude\n');
fprintf('----------------+-----------\n');
for i = 1:min(15, length(freq_picos_short))
    fprintf('%.1f            | %.2f\n', freq_picos_short(i), picos_mag_short(i));
end

fprintf('\nObservacao: Com apenas 51 amostras, aparecem MAIS componentes em frequencia\n');
fprintf('devido ao aliasing. Frequencias acima de Nyquist (%.0f Hz) sao rebatidas.\n', Fa2/2);

% Atividade 2f: Solucao do aliasing
fprintf('\n\n=== ATIVIDADE 2f: Como Resolver Completamente o Aliasing? ===\n');
fprintf('\nSolucoes para evitar/resolver aliasing:\n');
fprintf('1) AUMENTAR FREQUENCIA DE AMOSTRAGEM (Fs):\n');
fprintf('   - Nyquist = Fs/2 deve ser > maior frequencia do sinal\n');
fprintf('   - Exemplo: Para observar ate 1000 Hz, use Fs >= 2000 Hz\n\n');

fprintf('2) USAR FILTRO ANTI-ALIASING (Lowpass Filter):\n');
fprintf('   - Filtro passa-baixa antes da amostragem\n');
fprintf('   - Corta frequencias > Nyquist antes de amostrar\n');
fprintf('   - Evita que componentes de alta frequencia se "rebatam"\n\n');

fprintf('3) COMBINACAO: Fs alta + Filtro anti-aliasing:\n');
fprintf('   - Forma mais robusta e pratica\n');
fprintf('   - Garante representacao correta do sinal\n\n');

fprintf('Para a onda quadrada de 20 Hz com harmonicos ate ~200 Hz:\n');
fprintf('   - Minimo Fs necessario: 400 Hz (Nyquist = 200 Hz)\n');
fprintf('   - Recomendado: Fs >= 2000 Hz para boa resolucao\n\n');

fprintf('=== FIM DA ATIVIDADE 2 ===\n');