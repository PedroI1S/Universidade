-- =====================================================================
-- Projeto: PR2 - Gerador de Sinais (DE10-Lite)
-- Disciplina: Logica Reconfiguravel - LR27CP-7CP - Prof. MSc. Andre Macario Barros
-- Equipe (nome - RA):
--   Rodrigo Rodriguez Tato Gama da Silva - RA: 2562804
--   Pedro Mariano dos Santos             - RA: 2562790
--   Marlon Mezomo Gotardo                - RA: 2562766
-- Circuito implementado: dente de serra / rampa crescente (wav 5)
--   (variante de Marlon Mezomo Gotardo: freq1 = 400 Hz, freq2 = 800 Hz, n = 8 bits)
-- Link do video: https://drive.google.com/file/d/1KWd3NvJeDMjpvWbJ5SBJI3iQn9tCxyli/view?usp=drivesdk
-- Conversor D/A R-2R: R = 10 kOhm, 2R = 20 kOhm
-- =====================================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity conformador_onda is
  generic (N_BITS : natural := 8);
  port (
    fase_msb : in  unsigned(N_BITS-1 downto 0);
    sel_onda : in  std_logic;  -- '0'=quadrada, '1'=dente de serra
    dado     : out std_logic_vector(N_BITS-1 downto 0)
  );
end entity;

architecture rtl of conformador_onda is
  signal serra    : std_logic_vector(N_BITS-1 downto 0);
  signal quadrada : std_logic_vector(N_BITS-1 downto 0);
begin
  serra    <= std_logic_vector(fase_msb);
  quadrada <= (others => fase_msb(N_BITS-1));
  dado     <= serra when sel_onda = '1' else quadrada;
end architecture;
