# PR3 — Máquina de Lavar (DE10-Lite)

Lógica Reconfigurável (LR27CP-7CP) — Prof. MSc. André Macário Barros.
Placa **Terasic DE10-Lite** · FPGA **MAX 10 10M50DAF484C7G** · **Quartus Prime 20.1.1** · **VHDL-2008**.

Equipe (nome — RA):
- Rodrigo Rodriguez Tato Gama da Silva — 2562804
- Pedro Mariano dos Santos — 2562790
- Marlon Mezomo Gotardo — 2562766

## Descrição

Controle de uma "máquina de lavar" como uma **máquina de estados finitos (FSM)** de
4 estados, em ordem cíclica:

```
stand by --key1--> enxágue --key1--> molho --key1--> centrífuga --key1--> stand by
   ^                                                                          |
   +------------------ key0 (a qualquer momento, qualquer estado) ------------+
```

- **key1** (pushbutton): avança para o próximo estado.
- **key0** (pushbutton): retorna ao `stand by` a qualquer momento (tem prioridade).
- Ambos são **ativo-baixo** e passam por sincronização + debounce + detecção de borda.
- Estado inicial (power-on): `stand by`.

## Comportamento por estado

| Estado | LEDs (LEDR9..LEDR0) | HEX2 HEX1 HEX0 | Frequência |
|--------|---------------------|----------------|------------|
| stand by | só LEDR0 aceso | `Stb` | — |
| enxágue | LEDR9–5 ⇄ LEDR4–0 (alterna) | `EnH` | onda quadrada 1 Hz (inverte a cada 0,5 s) |
| molho | LEDR9 pisca, resto apagado | `nOL` | 0,5 Hz (1 s aceso / 1 s apagado) |
| centrífuga | 1 LED por vez, LEDR0→LEDR9 | `CEn` | passo a 10 Hz |

HEX5–HEX3 sempre apagados; ponto decimal apagado.

## Arquivos / módulos

| Arquivo | Responsabilidade |
|---------|------------------|
| `lavadora_pkg.vhd` | Pacote: tipo `estado_t`, constantes, função `calc_div`, declaração dos componentes |
| `divisor_clock.vhd` | Gera *enable* de 1 ciclo a cada `DIV` ciclos (parametrizável) |
| `sincronizador_botao.vhd` | Sincroniza + debounce + borda do pushbutton → pulso de 1 ciclo |
| `maquina_estados.vhd` | FSM dos 4 estados (avança / reset prioritário) |
| `gerador_leds.vhd` | Estado + 3 divisores → padrões de `LEDR[9:0]` |
| `decodificador_7seg.vhd` | Estado → segmentos de HEX2/HEX1/HEX0 (ativo-baixo) |
| `lavadora.vhd` | Entidade TOP (VHDL) — instancia tudo via pacote |
| `DE10_LITE_Golden_Top.v` | Top de síntese (Verilog): pinos oficiais da placa, instancia `lavadora` |
| `lavadora.sdc` | Constraints de timing (clock 50 MHz, false paths) |
| `lavadora.qsf` / `.qpf` | Projeto Quartus + pinout completo da DE10-Lite |

Cada componente tem um testbench `*_tb.vhd` (TDD) + o de integração `lavadora_tb.vhd`.

## Simulação (ghdl + surfer)

Da raiz do repositório:

```
./vhdl_run.sh projeto3 <nome_do_tb>          # analisa, elabora e roda
./vhdl_run.sh projeto3 lavadora_tb --open    # abre a forma de onda no surfer
```

Testbenches disponíveis:

- `lavadora_pkg_tb` — função `calc_div`
- `divisor_clock_tb` — período do *enable*
- `sincronizador_botao_tb` — debounce/borda → 1 pulso por toque
- `maquina_estados_tb` — ciclo dos 4 estados + reset prioritário
- `decodificador_7seg_tb` — segmentos das 4 mensagens
- `gerador_leds_tb` — padrões de LED por estado
- `lavadora_tb` — integração (avança pelos estados + reset)

Todos terminam com `<tb>: sucesso`.

## Síntese e gravação (Quartus Prime 20.1.1)

1. Abrir `lavadora.qpf` no Quartus.
2. Top-level entity = **`DE10_LITE_Golden_Top`** (já no `.qsf`).
3. Compilar e gravar na DE10-Lite (Programmer).
4. Conferir os pinos no Pin Planner contra o `.qsf` (padrão Terasic DE10-Lite).

> O `.sdc` define o clock de 50 MHz em 20 ns; sem ele o Quartus assume 1 GHz e o
> relatório de timing aparece com slack negativo (falso alarme).

## Empacotamento (Moodle)

Antes de zipar, apagar as pastas de compilação geradas pelo Quartus:

```
db/  incremental_db/  output_files/  simulation/
```

Compactar a pasta `projeto3/` em `.zip` ou `.rar` (limite 20 MB). Manter os `.vhd`
(projeto + testbenches), `DE10_LITE_Golden_Top.v`, `lavadora.qpf/.qsf/.sdc` e este README.
